from flask import Flask
from app import db  # 数据库实例（在app/__init__.py中初始化）
import os
import sys
from flask import Flask, render_template  # 添加 render_template 导入

# 初始化Flask应用
app = Flask(__name__,template_folder='app/templates')

# 数据库配置（替换为你的实际配置）
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:123456@localhost/warehouse_db?charset=utf8mb4'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'your_secure_secret_key'  # 用于flash消息和会话

# 初始化数据库
db.init_app(app)

# 获取当前文件（run.py）的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 将项目根目录加入 Python 搜索路径
sys.path.insert(0, current_dir)

# 确保 routes 和其子模块中有 __init__.py 文件
try:
    from app.routes.main import main_bp  # 总导航
    from app.routes.material import material_bp  # 物资管理
    from app.routes.material_category import material_category_bp  # 物资分类
    from app.routes.supplier import supplier_bp  # 供应商管理
    from app.routes.inbound import inbound_bp  # 入库管理
    from app.routes.outbound import outbound_bp  # 出库管理
    from app.routes.warehouse import warehouse_bp  # 仓库管理
    from app.routes.unit import unit_bp  # 单位管理
    from app.routes.stock import stock_bp  # 库存管理
    from app.routes.stock import stock_bp  # 库存模块
    
except ImportError as e:
    print(f"导入路由模块时出错: {e}")
    sys.exit(1)

app.register_blueprint(main_bp)
app.register_blueprint(material_bp)
app.register_blueprint(material_category_bp)
app.register_blueprint(supplier_bp)
app.register_blueprint(inbound_bp)
app.register_blueprint(outbound_bp)
app.register_blueprint(warehouse_bp)
app.register_blueprint(unit_bp)
app.register_blueprint(stock_bp)

@app.route('/')
def index():
    return render_template('index.html') 
# 启动服务
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # 确保数据库表存在
    app.run(host='0.0.0.0', port=5000, debug=True)  # 生产环境关闭debug