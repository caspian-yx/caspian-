from flask import Blueprint, render_template, request, redirect, url_for, flash
from app import db
from app.models import Warehouse  # 仓库模型

# 仓库模块蓝图，路由前缀：/warehouse
warehouse_bp = Blueprint('warehouse', __name__, url_prefix='/warehouse')

# 1. 仓库列表页（支持搜索）
@warehouse_bp.route('/list')
def warehouse_list():
    keyword = request.args.get('keyword', '').strip()
    query = Warehouse.query
    if keyword:
        # 支持搜索：名称、位置、负责人
        query = query.filter(
            db.or_(
                Warehouse.name.like(f'%{keyword}%'),
                Warehouse.location.like(f'%{keyword}%'),
                Warehouse.manager.like(f'%{keyword}%')
            )
        )
    warehouses = query.all()
    return render_template('warehouse_list.html', warehouses=warehouses, keyword=keyword)

# 2. 新增仓库（保持原逻辑）
@warehouse_bp.route('/add', methods=['GET', 'POST'])
def warehouse_add():
    if request.method == 'POST':
        name = request.form.get('name')
        location = request.form.get('location')
        manager = request.form.get('manager')
        phone = request.form.get('phone')
        
        if not name:
            flash('仓库名称不能为空', 'error')
            return render_template('warehouse_add.html')
        
        new_warehouse = Warehouse(
            name=name,
            location=location,
            manager=manager,
            phone=phone,
            is_active=1  # 默认为启用
        )
        db.session.add(new_warehouse)
        db.session.commit()
        flash('新增成功', 'success')
        return redirect(url_for('warehouse.warehouse_list'))
    
    return render_template('warehouse_add.html')

# 3. 编辑仓库（保持原逻辑）
@warehouse_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
def warehouse_edit(id):
    warehouse = Warehouse.query.get_or_404(id)
    if request.method == 'POST':
        warehouse.name = request.form.get('name')
        warehouse.location = request.form.get('location')
        warehouse.manager = request.form.get('manager')
        warehouse.phone = request.form.get('phone')
        warehouse.is_active = 1 if request.form.get('is_active') else 0  # 启用状态
        db.session.commit()
        flash('编辑成功', 'success')
        return redirect(url_for('warehouse.warehouse_list'))
    
    return render_template('warehouse_edit.html', warehouse=warehouse)

# 4. 删除仓库（保持原逻辑）
@warehouse_bp.route('/delete/<int:id>')
def warehouse_delete(id):
    warehouse = Warehouse.query.get_or_404(id)
    db.session.delete(warehouse)
    db.session.commit()
    flash('删除成功', 'success')
    return redirect(url_for('warehouse.warehouse_list'))