from flask import Blueprint, render_template, request, redirect, url_for, flash
from app import db
from app.models import Outbound, OutboundDetail, Warehouse, Material
from datetime import datetime

# 预设部门列表
DEPARTMENTS = ['采购部', '销售部', '财务部', '技术部', '仓储部', '人事部', '行政部', '市场部']
outbound_bp = Blueprint('outbound', __name__, url_prefix='/outbound')

# 出库单列表（带搜索）
@outbound_bp.route('/list')
def outbound_list():
    keyword = request.args.get('keyword', '').strip()
    query = Outbound.query.join(Warehouse)  # 关联仓库表
    if keyword:
        query = query.filter(
            db.or_(
                Outbound.outbound_id.like(f'%{keyword}%'),  # 按出库单号搜索
                Outbound.dept_name.like(f'%{keyword}%'),     # 按部门搜索
                Warehouse.name.like(f'%{keyword}%') # 按仓库名称搜索
            )
        )
    outbounds = query.order_by(Outbound.outbound_date.desc()).all()  # 按日期倒序
    return render_template('outbound_list.html', outbounds=outbounds, keyword=keyword)

# 新增出库单（自动填充日期+物资下拉框）
@outbound_bp.route('/add', methods=['GET', 'POST'])
def outbound_add():
    # 查询所有需要的下拉框数据
    warehouses = Warehouse.query.all()  # 仓库列表
    materials = Material.query.all()    # 物资列表（关键：确保物资下拉框有数据）
    
    if request.method == 'POST':
        # 生成唯一出库单号（格式：OUT+时间戳）
        outbound_id = f"OUT{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # 处理出库日期：优先用前端传递的值，若为空则用当前日期（双重保障）
        outbound_date = request.form.get('outbound_date') or datetime.now().strftime('%Y-%m-%d')
        
        # 创建出库单主记录
        new_outbound = Outbound(
            outbound_id=outbound_id,
            warehouse_id=request.form.get('warehouse_id'),
            dept_name=request.form.get('dept_name'),
            outbound_date=outbound_date,  # 确保日期非空
            remark=request.form.get('remark'),
            audit_status=0  # 默认为未审核
        )
        db.session.add(new_outbound)
        db.session.commit()
        
        # 添加明细（简化：直接从表单获取并添加，实际可跳转编辑页）
        material_id = request.form.get('material_id')
        quantity = request.form.get('quantity')
        if material_id and quantity:
            detail = OutboundDetail(
                outbound_id=outbound_id,
                material_id=material_id,
                quantity=int(quantity)
            )
            db.session.add(detail)
            db.session.commit()
        
        flash('出库单创建成功', 'success')
        # 跳转到编辑页（使用outbound_id作为参数，与路由匹配）
        return redirect(url_for('outbound.outbound_edit', outbound_id=new_outbound.outbound_id))
    
    # 传递数据到模板
    return render_template(
        'outbound_add.html',
        warehouses=warehouses,
        departments=DEPARTMENTS,
        materials=materials  # 关键：传递物资列表，确保下拉框有数据
    )

# 编辑出库单（含明细）
@outbound_bp.route('/edit/<string:outbound_id>', methods=['GET', 'POST'])
def outbound_edit(outbound_id):
    outbound = Outbound.query.get_or_404(outbound_id)  # 用outbound_id查询
    materials = Material.query.all()  # 物资列表
    details = OutboundDetail.query.filter_by(outbound_id=outbound_id).all()  # 明细列表
    
    if request.method == 'POST':
        # 更新出库单主信息
        outbound.warehouse_id = request.form.get('warehouse_id')
        outbound.dept_name = request.form.get('dept_name')
        outbound.outbound_date = request.form.get('outbound_date') or datetime.now().strftime('%Y-%m-%d')
        outbound.remark = request.form.get('remark')
        outbound.audit_status = int(request.form.get('audit_status', 0))
        
        # 先删除旧明细，再添加新明细
        OutboundDetail.query.filter_by(outbound_id=outbound_id).delete()
        material_ids = request.form.getlist('material_id[]')
        quantities = request.form.getlist('quantity[]')
        
        for mat_id, qty in zip(material_ids, quantities):
            if mat_id and qty:
                qty = int(qty)
                # 检查库存（审核通过时）
                mat = Material.query.get(mat_id)
                if outbound.audit_status == 1 and mat.stock < qty:
                    flash(f'物资【{mat.name}】库存不足', 'error')
                    return redirect(url_for('outbound.outbound_edit', outbound_id=outbound_id))
                
                # 添加新明细
                detail = OutboundDetail(
                    outbound_id=outbound_id,
                    material_id=mat_id,
                    quantity=qty
                )
                db.session.add(detail)
                
                # 审核通过则扣减库存
                if outbound.audit_status == 1:
                    mat.stock -= qty
        
        db.session.commit()
        flash('出库单更新成功', 'success')
        return redirect(url_for('outbound.outbound_list'))
    
    return render_template(
        'outbound_edit.html',
        outbound=outbound,
        materials=materials,
        details=details,
        warehouses=Warehouse.query.all(),
        departments=DEPARTMENTS
    )

# 删除出库单
@outbound_bp.route('/delete/<string:outbound_id>')
def outbound_delete(outbound_id):
    outbound = Outbound.query.get_or_404(outbound_id)
    # 先删除关联的明细
    OutboundDetail.query.filter_by(outbound_id=outbound_id).delete()
    # 再删除主单
    db.session.delete(outbound)
    db.session.commit()
    flash('出库单已删除', 'success')
    return redirect(url_for('outbound.outbound_list'))