from flask import Blueprint, render_template, request, redirect, url_for, flash
from app import db
from app.models import Inbound, InboundDetail, Supplier, Warehouse, Material
from datetime import datetime

inbound_bp = Blueprint('inbound', __name__, url_prefix='/inbound')


# 1. 入库单列表页（带搜索）
@inbound_bp.route('/list')
def inbound_list():
    keyword = request.args.get('keyword', '').strip()
    # 关联供应商和仓库，支持多字段搜索
    query = Inbound.query.join(Supplier).join(Warehouse)
    if keyword:
        query = query.filter(
            db.or_(
                Inbound.inbound_id.like(f'%{keyword}%'),  # 入库单号
                Supplier.name.like(f'%{keyword}%'),       # 供应商名称
                Warehouse.name.like(f'%{keyword}%')       # 仓库名称
            )
        )
    inbounds = query.order_by(Inbound.inbound_date.desc()).all()  # 按日期倒序
    return render_template('inbound_list.html', inbounds=inbounds, keyword=keyword)


# 2. 新增入库单
@inbound_bp.route('/add', methods=['GET', 'POST'])
def inbound_add():
    # 加载下拉框数据
    suppliers = Supplier.query.all()
    warehouses = Warehouse.query.all()
    materials = Material.query.all()
    # 生成当前日期（YYYY-MM-DD），用于前端默认值
    today = datetime.now().strftime('%Y-%m-%d')

    if request.method == 'GET':
        return render_template(
            'inbound_add.html',
            suppliers=suppliers,
            warehouses=warehouses,
            materials=materials,
            today=today  # 传递当前日期给模板
        )

    # POST提交处理
    else:
        # 处理入库日期（核心：确保非空且格式正确）
        inbound_date_str = request.form.get('inbound_date', '').strip()
        try:
            # 转换为date类型（匹配模型的db.Date）
            inbound_date = datetime.strptime(inbound_date_str, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            # 空值或格式错误时，用当前日期兜底
            inbound_date = datetime.now().date()

        # 创建入库单主单
        inbound_id = f"IN{datetime.now().strftime('%Y%m%d%H%M%S')}"
        new_inbound = Inbound(
            inbound_id=inbound_id,
            supplier_id=request.form.get('supplier_id'),
            warehouse_id=request.form.get('warehouse_id'),
            inbound_date=inbound_date,  # 传入有效日期
            remark=request.form.get('remark'),
            audit_status=0  # 默认为未审核
        )

        # 保存主单
        try:
            db.session.add(new_inbound)
            db.session.commit()
            flash('入库单创建成功，请添加明细', 'success')
            return redirect(url_for('inbound.inbound_edit', inbound_id=inbound_id))
        except Exception as e:
            db.session.rollback()
            flash(f'创建失败：{str(e)}', 'error')
            return render_template(
                'inbound_add.html',
                suppliers=suppliers,
                warehouses=warehouses,
                materials=materials,
                today=today
            )


# 3. 编辑入库单（含明细）
@inbound_bp.route('/edit/<string:inbound_id>', methods=['GET', 'POST'])
def inbound_edit(inbound_id):
    inbound = Inbound.query.get_or_404(inbound_id)
    materials = Material.query.all()
    details = InboundDetail.query.filter_by(inbound_id=inbound_id).all()
    today = datetime.now().strftime('%Y-%m-%d')  # 当前日期

    if request.method == 'GET':
        return render_template(
            'inbound_edit.html',
            inbound=inbound,
            materials=materials,
            details=details,
            suppliers=Supplier.query.all(),
            warehouses=Warehouse.query.all(),
            today=today
        )

    # POST提交处理
    else:
        # 处理入库日期（核心：确保有效）
        inbound_date_str = request.form.get('inbound_date', '').strip()
        try:
            inbound_date = datetime.strptime(inbound_date_str, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            # 错误时保留原日期（或用当前日期）
            inbound_date = inbound.inbound_date or datetime.now().date()

        # 更新主单信息
        inbound.supplier_id = request.form.get('supplier_id')
        inbound.warehouse_id = request.form.get('warehouse_id')
        inbound.inbound_date = inbound_date  # 传入有效日期
        inbound.remark = request.form.get('remark')
        inbound.audit_status = int(request.form.get('audit_status', 0))

        # 处理明细（先删旧明细，再添新明细）
        InboundDetail.query.filter_by(inbound_id=inbound_id).delete()
        material_ids = request.form.getlist('material_id[]')
        quantities = request.form.getlist('quantity[]')
        prices = request.form.getlist('unit_price[]')

        for mat_id, qty, price in zip(material_ids, quantities, prices):
            if mat_id and qty and price:
                # 添加新明细
                detail = InboundDetail(
                    inbound_id=inbound_id,
                    material_id=mat_id,
                    quantity=int(qty),
                    unit_price=float(price)
                )
                db.session.add(detail)
                # 审核通过则更新库存
                if inbound.audit_status == 1:
                    mat = Material.query.get(mat_id)
                    mat.stock += int(qty)

        # 保存更新
        try:
            db.session.commit()
            flash('入库单更新成功', 'success')
            return redirect(url_for('inbound.inbound_list'))
        except Exception as e:
            db.session.rollback()
            flash(f'更新失败：{str(e)}', 'error')
            return render_template(
                'inbound_edit.html',
                inbound=inbound,
                materials=materials,
                details=details,
                suppliers=Supplier.query.all(),
                warehouses=Warehouse.query.all(),
                today=today
            )


# 4. 删除入库单
@inbound_bp.route('/delete/<string:inbound_id>')
def inbound_delete(inbound_id):
    try:
        # 先删明细，再删主单
        InboundDetail.query.filter_by(inbound_id=inbound_id).delete()
        inbound = Inbound.query.get_or_404(inbound_id)
        db.session.delete(inbound)
        db.session.commit()
        flash('入库单已删除', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'删除失败：{str(e)}', 'error')
    return redirect(url_for('inbound.inbound_list'))