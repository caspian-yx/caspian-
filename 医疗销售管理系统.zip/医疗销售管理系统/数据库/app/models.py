from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from app import db  

# 1. 物资分类模型（对应 MaterialCategory）
class MaterialCategory(db.Model):
    __tablename__ = 'material_category'  # 数据库表名
    id = db.Column(db.Integer, primary_key=True)  # 主键（修正：使用id而非category_id）
    name = db.Column(db.String(100), nullable=False, unique=True)  # 分类名称（修正：使用name而非category_name）
    remark = db.Column(db.String(200))  # 补充备注字段（路由中用到）
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间

    # 关联物资（一个分类对应多个物资）
    materials = db.relationship('Material', backref='category', lazy=True)

# 2. 单位模型（对应 Unit）
class Unit(db.Model):
    __tablename__ = 'unit'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)  # 单位名称（如：个、千克）
    abbreviation = db.Column(db.String(20))  # 缩写（如：kg）

    # 关联物资
    materials = db.relationship('Material', backref='unit', lazy=True)


# 3. 供应商模型（对应 Supplier）
class Supplier(db.Model):
    __tablename__ = 'supplier'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # 供应商名称
    contact = db.Column(db.String(50))  # 联系人
    phone = db.Column(db.String(20))  # 电话
    address = db.Column(db.String(200))  # 地址
    create_time = db.Column(db.DateTime, default=datetime.now)

    # 关联入库单
    inbounds = db.relationship('Inbound', backref='supplier', lazy=True)


# 4. 仓库模型（对应 Warehouse）
class Warehouse(db.Model):
    __tablename__ = 'warehouse'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)  # 仓库名称
    location = db.Column(db.String(200))  # 位置
    manager = db.Column(db.String(50))  # 管理员
    phone = db.Column(db.String(20))  # 电话
    is_active = db.Column(db.Integer, default=1)  # 是否启用（1=启用，0=禁用）

    # 关联入库单和出库单
    inbounds = db.relationship('Inbound', backref='warehouse', lazy=True)
    outbounds = db.relationship('Outbound', backref='warehouse', lazy=True)


# 5. 物资模型（对应 Material）
class Material(db.Model):
    __tablename__ = 'material'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), nullable=False)  # 物资名称
    specification = db.Column(db.String(200))  # 规格
    category_id = db.Column(db.Integer, db.ForeignKey('material_category.id'))  # 关联分类
    unit_id = db.Column(db.Integer, db.ForeignKey('unit.id'))  # 关联单位
    stock = db.Column(db.Integer, default=0)  # 当前库存
    min_stock = db.Column(db.Integer, default=0)  # 最低库存预警
    create_time = db.Column(db.DateTime, default=datetime.now)
    remark = db.Column(db.String(500))
    
    # 关联入库明细、出库明细、盘点明细
    inbound_details = db.relationship('InboundDetail', backref='material', lazy=True)
    outbound_details = db.relationship('OutboundDetail', backref='material', lazy=True)
    stock_details = db.relationship('StockCheckDetail', backref='material', lazy=True)


# 6. 入库单主表（对应 Inbound）
class Inbound(db.Model):
    __tablename__ = 'inbound'
    inbound_id = db.Column(db.String(50), primary_key=True)  # 入库单号（如：IN20231114001）
    supplier_id = db.Column(db.Integer, db.ForeignKey('supplier.id'))  # 关联供应商
    warehouse_id = db.Column(db.Integer, db.ForeignKey('warehouse.id'))  # 关联仓库
    inbound_date = db.Column(db.Date, nullable=False)  # 入库日期
    total_amount = db.Column(db.Float, default=0)  # 总金额（可自动计算）
    remark = db.Column(db.Text)  # 备注
    audit_status = db.Column(db.Integer, default=0)  # 审核状态（0=未审核，1=已审核）
    create_time = db.Column(db.DateTime, default=datetime.now)

    # 关联入库明细
    details = db.relationship('InboundDetail', backref='inbound', lazy=True)


# 7. 入库单明细表（对应 InboundDetail）
class InboundDetail(db.Model):
    __tablename__ = 'inbound_detail'
    id = db.Column(db.Integer, primary_key=True)
    inbound_id = db.Column(db.String(50), db.ForeignKey('inbound.inbound_id'))  # 关联入库单
    material_id = db.Column(db.Integer, db.ForeignKey('material.id'))  # 关联物资
    quantity = db.Column(db.Integer, nullable=False)  # 入库数量
    unit_price = db.Column(db.Float, nullable=False)  # 单价
    amount = db.Column(db.Float)  # 金额（数量×单价）


# 8. 出库单主表（对应 Outbound）
class Outbound(db.Model):
    __tablename__ = 'outbound'
    outbound_id = db.Column(db.String(50), primary_key=True)  # 出库单号（如：OUT20231114001）
    dept_name = db.Column(db.String(100), nullable=False)  # 领用部门
    warehouse_id = db.Column(db.Integer, db.ForeignKey('warehouse.id'))  # 关联仓库
    outbound_date = db.Column(db.Date, nullable=False)  # 出库日期
    remark = db.Column(db.Text)  # 备注
    audit_status = db.Column(db.Integer, default=0)  # 审核状态
    create_time = db.Column(db.DateTime, default=datetime.now)

    # 关联出库明细
    details = db.relationship('OutboundDetail', backref='outbound', lazy=True)


# 9. 出库单明细表（对应 OutboundDetail）
class OutboundDetail(db.Model):
    __tablename__ = 'outbound_detail'
    id = db.Column(db.Integer, primary_key=True)
    outbound_id = db.Column(db.String(50), db.ForeignKey('outbound.outbound_id'))  # 关联出库单
    material_id = db.Column(db.Integer, db.ForeignKey('material.id'))  # 关联物资
    quantity = db.Column(db.Integer, nullable=False)  # 出库数量
    reason = db.Column(db.String(200))  # 出库原因


# 10. 库存盘点主表（对应 StockCheck）
class StockCheck(db.Model):
    __tablename__ = 'stock_check'
    check_id = db.Column(db.String(50), primary_key=True)  # 盘点单号（如：CHECK20231114001）
    checker = db.Column(db.String(50), nullable=False)  # 盘点人
    check_date = db.Column(db.Date, nullable=False)  # 盘点日期
    remark = db.Column(db.Text)  # 备注
    create_time = db.Column(db.DateTime, default=datetime.now)

    # 关联盘点明细
    details = db.relationship('StockCheckDetail', backref='check', lazy=True)


# 11. 库存盘点明细表（对应 StockCheckDetail）
class StockCheckDetail(db.Model):
    __tablename__ = 'stock_check_detail'
    id = db.Column(db.Integer, primary_key=True)
    check_id = db.Column(db.String(50), db.ForeignKey('stock_check.check_id'))  # 关联盘点单
    material_id = db.Column(db.Integer, db.ForeignKey('material.id'))  # 关联物资
    system_stock = db.Column(db.Integer, nullable=False)  # 系统库存
    actual_stock = db.Column(db.Integer, nullable=False)  # 实际库存
    diff = db.Column(db.Integer)  # 差异（实际-系统）