import os
import sys
from faker import Faker
from datetime import datetime
import random

# 导入项目路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from app import db
from app.models import (
    Material, MaterialCategory, Unit, Supplier,
    Warehouse, Inbound, InboundDetail,
    Outbound, OutboundDetail,
    StockCheck, StockCheckDetail
)
from run import app

# 初始化Faker（中文数据）
fake = Faker('zh_CN')
# 自定义部门列表（用于出库单）
DEPARTMENTS = ['采购部', '销售部', '财务部', '技术部', '仓储部', '人事部']

# 生成数据量配置
CATEGORY_COUNT = 5       # 物资分类
UNIT_COUNT = 10          # 单位
MATERIAL_COUNT = 50      # 物资
SUPPLIER_COUNT = 15      # 供应商
WAREHOUSE_COUNT = 3      # 仓库
INBOUND_COUNT = 30       # 入库单
OUTBOUND_COUNT = 25      # 出库单
STOCK_CHECK_COUNT = 8    # 盘点单

def init_data():
    with app.app_context():
        # 1. 清空现有表并重建（谨慎使用！）
        db.drop_all()
        db.create_all()
        print("数据库表已重置")

        # 2. 生成物资分类
        categories = []
        category_names = ["电子设备", "办公用品", "五金工具", "化工原料", "日用百货"]
        for name in category_names:
            c = MaterialCategory(name=name)
            db.session.add(c)
            categories.append(c)
        db.session.commit()
        print(f"生成 {len(categories)} 个物资分类")

        # 3. 生成单位
        units = []
        names = ["个", "台", "件", "千克", "米", "升", "套", "包", "箱", "支"]
        for name in names:
            u = Unit(name=name, abbreviation=name[0])
            db.session.add(u)
            units.append(u)
        db.session.commit()
        print(f"生成 {len(units)} 个单位")

        # 4. 生成物资（核心修复：移除手动设置id，补充正确的unit_id）
        materials = []
        for i in range(MATERIAL_COUNT):
            category = random.choice(categories)
            unit = random.choice(units)
            m = Material(
                name=f"{category.name}-{fake.word()}{i}",  # 避免重名（如“电子设备-键盘0”）
                specification=fake.text()[:20],
                category_id=category.id,
                unit_id=unit.id,  # 正确关联单位的外键（之前误写成id=unit.id）
                stock=random.randint(50, 500),  # 初始库存50-500
                create_time=fake.date_time_between(start_date='-1y', end_date='now')
                # 不手动设置id，由数据库自增生成
            )
            db.session.add(m)
            materials.append(m)
        db.session.commit()
        print(f"生成 {len(materials)} 个物资")

        # 5. 生成供应商
        suppliers = []
        for _ in range(SUPPLIER_COUNT):
            s = Supplier(
                name=fake.company(),
                contact=fake.name(),
                phone=fake.phone_number(),
                address=fake.address()
            )
            db.session.add(s)
            suppliers.append(s)
        db.session.commit()
        print(f"生成 {len(suppliers)} 个供应商")

        # 6. 生成仓库
        warehouses = []
        for i in range(WAREHOUSE_COUNT):
            w = Warehouse(
                name=f"仓库{i+1}-{fake.word()}",  # 如“仓库1-东区”
                location=fake.address(),
                manager=fake.name(),
                phone=fake.phone_number(),
                is_active=1
            )
            db.session.add(w)
            warehouses.append(w)
        db.session.commit()
        print(f"生成 {len(warehouses)} 个仓库")

        # 7. 生成入库单及明细
        for _ in range(INBOUND_COUNT):
            # 唯一入库单号：IN+时间戳+随机数
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]
            random_num = random.randint(100000, 999999)
            inbound_id = f"IN{timestamp}{random_num}"
            
            # 随机选择供应商和仓库
            supplier = random.choice(suppliers)
            warehouse = random.choice(warehouses)
            
            inbound = Inbound(
                inbound_id=inbound_id,
                supplier_id=supplier.id,
                warehouse_id=warehouse.id,
                inbound_date=fake.date_between(start_date='-6m', end_date='now'),
                remark=fake.text()[:50],
                audit_status=random.choice([0, 1, 2])  # 0未审核，1通过，2驳回
            )
            db.session.add(inbound)

            # 每个入库单包含1-4种物资
            for _ in range(random.randint(1, 4)):
                material = random.choice(materials)
                quantity = random.randint(10, 100)  # 入库数量
                unit_price = round(random.uniform(10, 500), 2)  # 单价
                
                # 添加入库明细
                detail = InboundDetail(
                    inbound_id=inbound_id,
                    material_id=material.id,
                    quantity=quantity,
                    unit_price=unit_price
                )
                db.session.add(detail)
                
                # 已审核的入库单更新库存
                if inbound.audit_status == 1:
                    material.stock += quantity
        db.session.commit()
        print(f"生成 {INBOUND_COUNT} 个入库单（含明细）")

        # 8. 生成出库单及明细
        for _ in range(OUTBOUND_COUNT):
            # 唯一出库单号：OUT+时间戳+随机数
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]
            random_num = random.randint(100000, 999999)
            outbound_id = f"OUT{timestamp}{random_num}"
            
            warehouse = random.choice(warehouses)
            outbound = Outbound(
                outbound_id=outbound_id,
                warehouse_id=warehouse.id,
                dept_name=random.choice(DEPARTMENTS),  # 领用部门
                outbound_date=fake.date_between(start_date='-3m', end_date='now'),
                remark=fake.text()[:50],
                audit_status=random.choice([0, 1, 2])
            )
            db.session.add(outbound)

            # 每个出库单包含1-3种物资（确保库存足够）
            for _ in range(random.randint(1, 3)):
                material = random.choice(materials)
                # 出库数量不超过当前库存
                max_quantity = min(30, material.stock) if material.stock > 0 else 1
                quantity = random.randint(1, max_quantity)
                
                # 添加出库明细
                detail = OutboundDetail(
                    outbound_id=outbound_id,
                    material_id=material.id,
                    quantity=quantity
                )
                db.session.add(detail)
                
                # 已审核的出库单更新库存
                if outbound.audit_status == 1 and material.stock >= quantity:
                    material.stock -= quantity
        db.session.commit()
        print(f"生成 {OUTBOUND_COUNT} 个出库单（含明细）")

        # 9. 生成库存盘点单及明细
        for _ in range(STOCK_CHECK_COUNT):
            # 唯一盘点单号：CHECK+时间戳+随机数
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]
            random_num = random.randint(100000, 999999)
            check_id = f"CHECK{timestamp}{random_num}"
            
            check = StockCheck(
                check_id=check_id,
                checker=fake.name(),  # 盘点人
                check_date=fake.date_between(start_date='-1m', end_date='now'),
                remark=fake.text()[:50]
            )
            db.session.add(check)

            # 每个盘点单包含5-10种物资
            checked_materials = random.sample(materials, min(10, len(materials)))
            for mat in checked_materials:
                system_stock = mat.stock  # 系统库存
                actual_stock = system_stock + random.randint(-5, 5)  # 实际库存（允许±5误差）
                detail = StockCheckDetail(
                    check_id=check_id,
                    material_id=mat.id,
                    system_stock=system_stock,
                    actual_stock=actual_stock,
                    diff=actual_stock - system_stock  # 差异
                )
                db.session.add(detail)
        db.session.commit()
        print(f"生成 {STOCK_CHECK_COUNT} 个盘点单（含明细）")

        print("所有数据生成完成！入库、出库、盘点单已填充数据。")

if __name__ == '__main__':
    init_data()